from . import pacientes, fila, medicos
